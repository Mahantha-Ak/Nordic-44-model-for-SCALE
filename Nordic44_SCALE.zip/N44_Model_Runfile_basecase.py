import os, sys
import math
from time import sleep

# Locations of PSSE and CASE

PSSE_LOCATION = r"C:\Program Files\PTI\PSSE35\35.3\PSSBIN"  # CHANGE THIS IF ANOTHER VERSION IS USED
STUFF_LOC = r"C:\Program Files\PTI\PSSE35\35.3\PSSPY37"  # CHANGE THIS IF ANOTHER PSSE VERSION IS USED THAN 35.X
sys.path.append(PSSE_LOCATION)
sys.path.append(STUFF_LOC)
os.environ['PATH'] = os.environ['PATH'] + ';' + PSSE_LOCATION

import psse3503
import psspy
import dyntools
import redirect

redirect.psse2py()

# SET FILE names
study = 'Nordic44_SE_BESS'
suffix = '_flat'
savfile = r"""Nordic44_SE_BESS.sav"""
snpfile = '%s.snp' % study
logfile = '%s%s.log' % (study, suffix)
psspy.progress_output(2, logfile, [0, 0])

# SET PSSE DEFAULTS
_i = psspy.getdefaultint()
_f = psspy.getdefaultreal()
_s = psspy.getdefaultchar()

psspy.psseinit()
# -------------------------------------------------------------------------
# 1: LOAD PSSE CASE
# -------------------------------------------------------------------------
# Loading the save file
psspy.case(savfile)

# Setting the solution parameters
psspy.solution_parameters_3([_i, 100, _i],
                            [_f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f, _f])

# Converting EV generator models to renewable generators and specifying the Pmax for FCR-D up

psspy.machine_data_2(3100, r"""1""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(3115, r"""4""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(3200, r"""1""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(3244, r"""1""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(6100, r"""6""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(6500, r"""5""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(7100, r"""4""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 121.7978, 0, 121.7978, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

# Converting EV generator models to renewable generators and specifying the Pmax for FFR

psspy.machine_data_2(5501, r"""1""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 100, 0, 100, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(5300, r"""3""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 100, 0, 100, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_2(8500, r"""7""",
                     [_i, _i, _i, _i, _i, 1],
                     [0, 0, 0, 0, 100, 0, 100, _f, 99999.0, _f, _f, _f, _f, _f, _f, _f, _f])

# Converting certain conventional generators to wind

# psspy.machine_data_4(3000, r"""1""", [_i, _i, _i, _i, _i, 1],
#                      [1100, 967, 967, -967, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
# psspy.machine_data_4(3000, r"""2""", [_i, _i, _i, _i, _i, 1],
#                      [1100, 967, 967, -967, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_4(3249, r"""1""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3249, r"""2""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3249, r"""3""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3249, r"""4""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3249, r"""5""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3249, r"""6""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3249, r"""7""", [_i, _i, _i, _i, _i, 1],
                     [1042, 88.77, 986, -986, 1230, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_4(3300, r"""1""", [_i, _i, _i, _i, _i, 1],
                     [657.719, 440.251, 767, -767, 1000, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3300, r"""2""", [_i, _i, _i, _i, _i, 1],
                     [657.719, 440.251, 767, -767, 1000, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(3300, r"""3""", [_i, _i, _i, _i, _i, 1],
                     [657.719, 440.251, 767, -767, 1000, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])

psspy.machine_data_4(6500, r"""1""", [_i, _i, _i, _i, _i, 1],
                     [814.333, 356.584, 800, -800, 1000, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(6500, r"""2""", [_i, _i, _i, _i, _i, 1],
                     [814.333, 356.584, 800, -800, 1000, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(6500, r"""3""", [_i, _i, _i, _i, _i, 1],
                     [814.333, 356.584, 800, -800, 1000, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])

# psspy.machine_data_4(7000, r"""1""", [_i, _i, _i, _i, _i, 1],
#                      [1085.5, 158.744, 911, -911, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
# psspy.machine_data_4(7000, r"""2""", [_i, _i, _i, _i, _i, 1],
#                      [1085.5, 158.744, 911, -911, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(7000, r"""3""", [_i, _i, _i, _i, _i, 1],
                     [1085.5, 158.744, 911, -911, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(7000, r"""4""", [_i, _i, _i, _i, _i, 1],
                     [1085.5, 158.744, 911, -911, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(7000, r"""5""", [_i, _i, _i, _i, _i, 1],
                     [1085.5, 158.744, 911, -911, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])
psspy.machine_data_4(7000, r"""6""", [_i, _i, _i, _i, _i, 1],
                     [1085.5, 158.744, 911, -911, 1167, 0, 5000, _f, 9999.0, _f, _f, _f, _f, _f, _f, _f, _f])

# Change the swing bus from 3300 to 3359
psspy.bus_chng_4(3300, 0, [2, _i, _i, _i], [_f, _f, _f, _f, _f, _f, _f], _s)
psspy.bus_chng_4(3359, 0, [3, _i, _i, _i], [_f, _f, _f, _f, _f, _f, _f], _s)

psspy.bus_chng_4(3100, 0, [2, _i, _i, _i], [_f, _f, _f, _f, _f, _f, _f], _s)
psspy.bus_chng_4(3200, 0, [2, _i, _i, _i], [_f, _f, _f, _f, _f, _f, _f], _s)
psspy.bus_chng_4(3244, 0, [2, _i, _i, _i], [_f, _f, _f, _f, _f, _f, _f], _s)
psspy.bus_chng_4(5501, 0, [2, _i, _i, _i], [_f, _f, _f, _f, _f, _f, _f], _s)

psspy.fdns([1, 0, 1, 1, 1, 0, 99, 0])
rawfile = 'Nordic44_SE_BESS.snp'
psspy.save(rawfile)
# -------------------------------------------------------------------------
# 2: convert case and create snp file
#
# -------------------------------------------------------------------------
# convert loads and generators and create converted case
psspy.conl(0, 1, 1, [0, 0], [0.0, 0.0, 0.0, 0.0])
psspy.conl(0, 1, 2, [0, 0], [0.0, 0.0, 0.0, 0.0])
psspy.conl(0, 1, 3, [0, 0], [0.0, 0.0, 0.0, 0.0])
psspy.cong()
psspy.ordr(0)
psspy.fact()
psspy.tysl(0)
cnvfile = 'Nordic44_SE_BESS_base_cnv.sav'
psspy.save(cnvfile)

# Load in the dyr file
dyrfile = 'Nordic44_Base_Low_H_Wind_testing.dyr'

psspy.dyre_new([1, 1, 1, 1], dyrfile,
               r"""conec.for""",
               r"""conet.for""", "")

# Add the user written .dll files to the model library
psspy.addmodellibrary(r"""USPMDL.dll""")
psspy.addmodellibrary(r"""USEMDL.dll""")
psspy.addmodellibrary(r"""USPFFR.dll""")
psspy.addmodellibrary(r"""USEFFR.dll""")
psspy.addmodellibrary(r"""WT4GU.dll""")

# Activate/deactivate units by changing Pmax CON

# FCR-D
Pmax_V2G = 0.0
psspy.change_wnmod_con(3100, '1', 'USPMDL', 6, Pmax_V2G)
psspy.change_wnmod_con(3115, '4', 'USPMDL', 6, Pmax_V2G)
psspy.change_wnmod_con(3200, '1', 'USPMDL', 6, Pmax_V2G)
psspy.change_wnmod_con(3244, '1', 'USPMDL', 6, Pmax_V2G)
psspy.change_wnmod_con(6100, '6', 'USPMDL', 6, Pmax_V2G)
psspy.change_wnmod_con(6500, '5', 'USPMDL', 6, Pmax_V2G)
psspy.change_wnmod_con(7100, '4', 'USPMDL', 6, Pmax_V2G)

# FFR
Pmax_FFR = 0.0
psspy.change_wnmod_con(5501, '1', 'USPFFR', 3, Pmax_FFR)
psspy.change_wnmod_con(5300, '3', 'USPFFR', 3, Pmax_FFR)
psspy.change_wnmod_con(8500, '7', 'USPFFR', 3, Pmax_FFR)

# Change the Gmax of the Hydro governor to control FCR contribution
# G_MAX settings
# ierr, con_3115_1 = psspy.mdlind(3115, '1', 'GOV', 'CON')
# ierr, con_3115_2 = psspy.mdlind(3115, '2', 'GOV', 'CON')
# ierr, con_3115_3 = psspy.mdlind(3115, '3', 'GOV', 'CON')
# ierr, con_6700_1 = psspy.mdlind(6700, '1', 'GOV', 'CON')
# ierr, con_6700_2 = psspy.mdlind(6700, '2', 'GOV', 'CON')
# ierr, con_7100_1 = psspy.mdlind(7100, '1', 'GOV', 'CON')
# ierr = psspy.change_con(con_3115_1+6, 0.943331817)
# ierr = psspy.change_con(con_3115_2+6, 0.943331817)
# ierr = psspy.change_con(con_3115_3+6, 0.943331817)
# ierr = psspy.change_con(con_6700_1+6, 0.950796167)
# ierr = psspy.change_con(con_6700_2+6, 0.950796167)
# ierr = psspy.change_con(con_7100_1+6, 0.848666333)

# Change the droop settings for EPC
# EPC settings
EPC_droop = 0
psspy.change_vsdcauxmod_con('KARLSH_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('ARRIE_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('KRISTIA_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('FEDA_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('STENKU_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('VYBORG_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('ESTLINK_HVDC', 1, 'CHAAUT', 4, EPC_droop)
psspy.change_vsdcauxmod_con('DANNEBO_HVDC', 1, 'CHAAUT', 4, EPC_droop)

# V2G model delay setting
# delay = 5.0
# psspy.change_wnmod_con(3100, '1', 'USPMDL', 2, delay)
# psspy.change_wnmod_con(3115, '4', 'USPMDL', 2, delay)
# psspy.change_wnmod_con(5300, '3', 'USPMDL', 2, delay)
# psspy.change_wnmod_con(6100, '6', 'USPMDL', 2, delay)
# psspy.change_wnmod_con(6500, '5', 'USPMDL', 2, delay)
# psspy.change_wnmod_con(7100, '4', 'USPMDL', 2, delay)
# psspy.change_wnmod_con(8500, '7', 'USPMDL', 2, delay)
outfile = 'Nordic44_BaseCase.out'

# Plot channels
ierr = psspy.delete_all_plot_channels()  # Deletes all channel outputs before the next iteration. Useful when looping is used

ierr, pvar = psspy.windmind(8500, '7', 'WAUX', 'VAR')
ierr, pstate = psspy.windmind(8500, '7', 'WAUX', 'STATE')
ierr, var = psspy.windmind(8500, '7', 'WELEC', 'VAR')
ierr, estate = psspy.windmind(8500, '7', 'WELEC', 'STATE')
ierr, dcvar = psspy.vscmind('ESTLINK_HVDC', 'VAR')
ierr, auxvar = psspy.vscauxmind('ESTLINK_HVDC', 1, 'VAR')
psspy.chsb(0, 1, [-1, -1, -1, 1, 1, 0])  # ANGLE, machine relative rotor angle (degrees).
psspy.chsb(0, 1, [-1, -1, -1, 1, 2, 0])  # PELEC, machine electrical power (pu on SBASE).
psspy.chsb(0, 1, [-1, -1, -1, 1, 3, 0])  # QELEC, machine reactive power.
psspy.chsb(0, 1, [-1, -1, -1, 1, 6, 0])  # PMECH
psspy.chsb(0, 1, [-1, -1, -1, 1, 12, 0])  # BSFREQ, bus pu frequency deviations.
psspy.chsb(0, 1, [-1, -1, -1, 1, 13, 0])  # VOLT, bus pu voltages (complex).
psspy.var_channel([-1, var + 4], "P0")
psspy.var_channel([-1, var + 5], "Ipcmd")
psspy.var_channel([-1, var + 2], "SOC")
psspy.var_channel([-1, var + 3], "V0")
psspy.state_channel([-1, estate], "Ip")
psspy.var_channel([-1, pvar], "fdiff")
psspy.var_channel([-1, pvar + 1], "Pdroop")
psspy.state_channel([-1, pstate], "f_filter")
psspy.var_channel([-1, pvar + 3], "f_delay")
psspy.state_channel([-1, pstate + 1], "Pref")
psspy.var_channel([-1, var], "OCV")
psspy.var_channel([-1, var + 1], "Vseries")
psspy.state_channel([-1, estate + 2], "Vtrans")
psspy.state_channel([-1, estate + 3], "Energy")
psspy.state_channel([-1, estate + 1], "Qdisch")
psspy.chsb(0, 1, [-1, -1, -1, 1, 25, 0])  # PLOAD, total active load
psspy.chsb(0, 1, [-1, -1, -1, 1, 26, 0])  # QLOAD, total active load
psspy.var_channel([-1, dcvar], "P_aux")
psspy.var_channel([-1, dcvar + 10], "PELEC")
psspy.var_channel([-1, dcvar + 11], "QELEC")

# ** Run dynamics simulation
# psspy.set_relang(0)
# ierr = psspy.dynamics_solution_param_2(intgar=[100], realar=[0.8, 0.005, 0.01, 0.04, 0.06, 0.14, 0.3, 0.0005])

# AKM settings
psspy.set_relang(0)
psspy.dynamics_solution_param_2([99, _i, _i, _i, _i, _i, _i, _i],
                                [1.0, _f, 0.01, 0.04, _f, _f, _f, _f])
psspy.set_netfrq(1)     # Network frequency dependence
psspy.set_chnfil_type(0)  # 1 for OUTX format, 0 for (old) OUT format
psspy.change_channel_out_file(outfile)
psspy.strt(1, outfile)

psspy.run(0, 10.0, 501, 1, 100)
# psspy.dist_machine_trip(6000, r"""1""")  # gen trip
# psspy.dist_machine_trip(7100, r"""3""")  # gen trip
# psspy.dist_machine_trip(6100, r"""2""")  # gen trip
psspy.change_ldmod_con(6100, '1', 'IEELBL', 3, 1.604)
# psspy.change_ldmod_con(6100, '1', 'IEELBL', 3, 0.42)
psspy.run(0, 150.0, 501, 1, 100)
psspy.progress_output(1)
